create definer = root@localhost trigger Address_AFTER_UPDATE
    after update
    on Address
    for each row
BEGIN
UPDATE hospital.EmployeeAddressMapping SET isActive = 1 WHERE old.id = Address_id;
UPDATE hospital.PatientAddressMapping SET isActive = 1 WHERE old.id = Address_id;
END;

