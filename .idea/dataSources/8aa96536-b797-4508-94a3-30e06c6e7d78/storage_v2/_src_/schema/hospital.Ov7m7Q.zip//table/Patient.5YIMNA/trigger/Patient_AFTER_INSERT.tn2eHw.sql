create definer = root@localhost trigger Patient_AFTER_INSERT
    after insert
    on Patient
    for each row
BEGIN
INSERT INTO PatientRegister values(new.id,new.id,CURDATE());
END;

