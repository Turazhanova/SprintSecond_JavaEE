create definer = root@localhost view PatientHasNotInsurance as
select `hospital`.`Patient`.`FirstName` AS `FirstName`, `hospital`.`Patient`.`LastName` AS `LastName`
from `hospital`.`Patient`
where `hospital`.`Patient`.`id` in (select `hospital`.`Insurance`.`Patient_id` from `hospital`.`Insurance`) is false;

