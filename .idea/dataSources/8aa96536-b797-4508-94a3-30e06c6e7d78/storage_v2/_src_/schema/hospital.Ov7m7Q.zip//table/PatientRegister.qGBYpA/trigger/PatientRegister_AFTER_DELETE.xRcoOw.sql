create definer = root@localhost trigger PatientRegister_AFTER_DELETE
    after delete
    on PatientRegister
    for each row
BEGIN
DELETE FROM hospital.Patient WHERE Patient.id = old.id;
END;

